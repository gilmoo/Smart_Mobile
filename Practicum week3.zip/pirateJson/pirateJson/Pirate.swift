//
//  Pirate.swift
//  pirateJson
//
//  Created by Ruthger van den Eikhof on 10-09-15.
//  Copyright (c) 2015 Ruthger van den Eikhof. All rights reserved.
//

import Foundation
class Pirate {
    var name: String?
    var life: String?
    var countryOfOrigin: String?
    var yearsActive: String?
    var comments: String?

    init(name: String!, life: String, countryOfOrigin: String, yearsActive: String, comments: String){
        self.name = name!
        self.life = life
        self.countryOfOrigin = countryOfOrigin
        self.yearsActive = yearsActive
        self.comments = comments
    }
}