//
//  TableViewController.swift
//
//
//  Created by Ruthger van den Eikhof on 10-09-15.
//
//

import UIKit

class TableViewController: UITableViewController {
    
    var pirates = [Pirate]()
    
    func loadJsonData(){
        var url  = "http://athena.fhict.nl/users/i886625/pirates.json"
        if let url = NSURL(string: url){
            if let data = NSData(contentsOfURL: url,options: .allZeros, error: nil){
                let json = JSON(data:data)
                    parseJSON(json)
                
            }
        }
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath)
        -> UITableViewCell{
        //let cell = tableView.dequeueReusableCellWithIdentifier("cell", forIndexPath: indexPath)
        //    as! UITableViewCell
            
        var cell = tableView.dequeueReusableCellWithIdentifier("cell") as? UITableViewCell
            if cell == nil {
                cell = UITableViewCell(style: UITableViewCellStyle.Value1, reuseIdentifier: "cell")
            }
        //set correct value in this cell.
        //do so by looking up in the row in indexpath and choosing the same element in the array
        var currentRow = indexPath.row
        var currentPirate = self.pirates[currentRow]
        //set the text in the cell
        cell!.textLabel?.text = currentPirate.name
        return cell!
    }
    
    func parseJSON(json: JSON) {
        for result in json.arrayValue {
            let name = result["name"].stringValue
            let life = result["life"].stringValue
            let countryOfOrigin = result["country_of_origin"].stringValue
            let yearsActive = result["years_active"].stringValue
            let comments = result["comments"].stringValue
            let pirate : Pirate = Pirate(name: name,life: life,countryOfOrigin: countryOfOrigin,yearsActive: yearsActive,comments: comments)
            pirates.append(pirate)
        }
        
        tableView.reloadData()
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        let pirate: Pirate = self.pirates[self.tableView.indexPathForSelectedRow()!.row]
        var controller = segue.destinationViewController as! DetailsViewController
        controller.selectedPirate = pirate
    }
    
    
    override func viewDidLoad() {
        self.loadJsonData()
        super.viewDidLoad()
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table view data source
    
    //override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Potentially incomplete method implementation.
        // Return the number of sections.
        //println("nr of pirates: \(pirates.count)")
      //  return pirates.count;
    //}
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete method implementation.
        // Return the number of rows in the section.
        return pirates.count
    }
    
    
    
    /*
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
    let cell = tableView.dequeueReusableCellWithIdentifier("reuseIdentifier", forIndexPath: indexPath) as! UITableViewCell
    
    // Configure the cell...
    
    return cell
    }
    */
    
    /*
    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
    // Return NO if you do not want the specified item to be editable.
    return true
    }
    */
    
    /*
    // Override to support editing the table view.
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
    if editingStyle == .Delete {
    // Delete the row from the data source
    tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
    } else if editingStyle == .Insert {
    // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }
    }
    */
    
    /*
    // Override to support rearranging the table view.
    override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {
    
    }
    */
    
    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
    // Return NO if you do not want the item to be re-orderable.
    return true
    }
    */
    
    /*
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    }
    */
    
}
