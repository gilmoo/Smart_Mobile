//
//  DetailsViewController.swift
//  pirateJson
//
//  Created by Ruthger van den Eikhof on 10-09-15.
//  Copyright (c) 2015 Ruthger van den Eikhof. All rights reserved.
//

import UIKit

class DetailsViewController: UIViewController {
    var selectedPirate : Pirate?
    override func viewDidLoad() {
        showName.text = selectedPirate?.name
        showLife.text = selectedPirate?.life
        showActiveYear.text = selectedPirate?.yearsActive
        showCountry.text = selectedPirate?.countryOfOrigin
        showComment.text = selectedPirate?.comments
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    @IBOutlet weak var showName: UILabel!
    
    @IBOutlet weak var showLife: UILabel!
    @IBOutlet weak var showActiveYear: UILabel!
    @IBOutlet weak var showCountry: UILabel!
    
    @IBOutlet weak var showComment: UITextView!
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
