//
//  City.swift
//  Hellglow world
//
//  Created by Ruthger van den Eikhof on 03-09-15.
//  Copyright (c) 2015 Ruthger van den Eikhof. All rights reserved.
//


class City {
    var name = ""
    var population = 0
    var glowActs : [GlowAct]
    var allString = ""
    
    func showInfo()-> String{
        for act : GlowAct in glowActs{
          allString = allString + "The act is called \(act.name) and starts at \(act.startTime). It is given an average rating of \(act.rating) \n"
        }
          allString = allString + "In the city of \(self.name) there are currently living \(self.population) people \n There are currently \(glowActs.count) glowActs"
        return allString
    }
    
    init(name:String, population:Int, glowAct: [GlowAct]){
        self.name = name
        self.population = population
        self.glowActs = glowAct
    }
}
