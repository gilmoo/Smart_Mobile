//
//  main.swift
//  Hellglow world
//
//  Created by Ruthger van den Eikhof on 03-09-15.
//  Copyright (c) 2015 Ruthger van den Eikhof. All rights reserved.
//

import Foundation

var blueLightAct = GlowAct(name: "The BlueLight Act.", startTime: "22:20", rating: 8)
var wishLaserAct = GlowAct(name: "Wish Laser Act.", startTime: "20:00", rating: 9)
//println(blueLightAct.showInfo())

var city = City(name: "Eindhoven", population: 220000, glowAct: [blueLightAct])
city.glowActs.append(wishLaserAct)
println(city.showInfo())


