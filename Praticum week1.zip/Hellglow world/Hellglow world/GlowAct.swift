//
//  GlowAct.swift
//  Hellglow world
//
//  Created by Ruthger van den Eikhof on 03-09-15.
//  Copyright (c) 2015 Ruthger van den Eikhof. All rights reserved.
//


class GlowAct {
    var name = ""
    var rating = 0
    var startTime = ""
    
    func showInfo()-> String{
        return "The act is called \(self.name) and starts at \(self.startTime). It is given an average rating of \(self.rating) \n"
    }
    
    init(name:String, startTime:String, rating:Int){
        self.name = name
        self.startTime = startTime
        self.rating = rating
    }
}

